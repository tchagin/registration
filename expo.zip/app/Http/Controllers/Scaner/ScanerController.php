<?php

namespace App\Http\Controllers\Scaner;

use App\Http\Controllers\Controller;
use App\Models\Member;
use Illuminate\Http\Request;

class ScanerController extends Controller
{
    public function editStatus($slug){
        $member = Member::where('slug', $slug)->firstOrFail();
        $member->update([
            'visitor' => 1,
        ]);
    }
}
