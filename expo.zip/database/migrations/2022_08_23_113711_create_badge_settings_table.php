<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBadgeSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('badge_settings', function (Blueprint $table) {
            $table->id();
            $table->tinyInteger('width')->nullable()->default('60');
            $table->tinyInteger('height')->nullable()->default('80');
            $table->enum('status', \App\Models\BadgeSettings::STATUS)->default(\App\Models\BadgeSettings::STATUS['off']);
            $table->enum('orientation', \App\Models\BadgeSettings::FORM)->default(\App\Models\BadgeSettings::FORM['vertically']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('badge_settings');
    }
}
