@extends('admin.layouts.layout')

@section('content')
    <section class="content">
        <div class="container-fluid">
            <!-- Default box -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">QR-панель</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <div class="scaner">
                        <div class="image">
                            <img src="{{ asset('assets/admin/img/custom/scaner.png') }}" alt="">
                        </div>
                        <div class="wrap">
                            <div class="header">
                                Сканировать
                            </div>
                            <div class="input-wrap">
                                <input type="text" class="form-control" placeholder="Нажмите для введения">
                            </div>
                        </div>
                    </div>
                    @if(count($exhibitions))
                    <div class="exhibitions row">
                        @foreach($exhibitions as $exhibition)
                            <div class="col-sm-4">
                                <div class="exhibition-block">
                                    <div class="exhibition-thumbnail">
                                        <img src="{{ $exhibition->getImage() }}" alt="" aria-hidden="true">
                                    </div>
                                    <div class="date">
                                        <p>Дата выставки</p>
                                        <p>{{ $exhibition->dateStart() }} - {{ $exhibition->dateFinish() }}</p>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div class="members">
                                            <div class="title">Посетители</div>
                                            <div class="d-flex align-items-center">
                                                <div class="count">{{ $exhibition->members->where('visitor', 1)->count() }}</div>
                                                <div class="ico"><img src="{{ asset('assets/admin/img/custom/panel-ico-1.png') }}" alt=""></div>
                                            </div>
                                        </div>
                                        <div class="members">
                                            <div class="title">Зарегистрированные</div>
                                            <div class="d-flex align-items-center">
                                                <div class="count">{{ $exhibition->members->count() }}</div>
                                                <div class="ico"><img src="{{ asset('assets/admin/img/custom/panel-ico-2.png') }}" alt=""></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
@endsection
