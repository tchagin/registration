<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="{{ asset('assets/admin/css/chart.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/admin/css/admin.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/admin/css/style.css') }}">
    <style>
        .ck-editor__editable_inline {
            min-height: 200px;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav w-100">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li><a href="{{ route('home') }}" class="nav-link" target="_blank">Перейти на сайт</a></li>
            {{--            <li class="nav-item ml-auto"><a href="{{ route('logout') }}" class="nav-link">Выйти</a></li>--}}
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="{{ route('logout') }}" class="nav-link">Выйти</a></li>
        </ul>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar">

        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Sidebar user (optional) -->
            <div class="logo">
                <img src="{{ asset('assets/admin/img/custom/logo.svg') }}" alt="">
            </div>
            <div class="user-panel mt-3 d-flex align-items-center">
                <div class="image">
                    <img src="{{ asset('assets/admin/img/user2-160x160.jpg') }}" class="img-circle elevation-2"
                         alt="User Image">
                </div>
                <div class="info">
                    <div class="d-block" style="color: #fff; white-space: normal">Администратор {{ auth()->user()->role }}</div>
                </div>
            </div>

            <!-- Sidebar Menu -->
            <nav class="">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                    data-accordion="false">
                    <li class="nav-item">
                        <a href="{{ route('admin.index') }}" class="nav-link">
                            <i class="nav-icon fa-solid fa-clipboard-list"></i>
                            <p>Статистика</p>
                        </a>
                    </li>
                    @if(auth()->user()->role == 'administrator')
                        <li class="nav-item">
                            <a href="{{ route('exhibitions.index') }}" class="nav-link">
                                <i class="nav-icon fa-solid fa-rectangle-list"></i>
                                <p>Выставки</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('advertising.index') }}" class="nav-link">
                                <i class="nav-icon fa-solid fa-rectangle-list"></i>
                                <p>Реклама</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('industries.index') }}" class="nav-link">
                                <i class="nav-icon fa-solid fa-rectangle-list"></i>
                                <p>Индустрия</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('inputs.index') }}" class="nav-link">
                                <i class="nav-icon fa-solid fa-barcode"></i>
                                <p>Поля для регистрации</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ route('members.index') }}" class="nav-link">
                                <i class="nav-icon fa-solid fa-id-card"></i>
                                <p>База данных</p>
                            </a>
                        </li>
                    @endif
                    <li class="nav-item">
                        <a href="{{ route('panel') }}" class="nav-link">
                            <i class="nav-icon fa-solid fa-id-card"></i>
                            <p>QR-Панель</p>
                        </a>
                    </li>
{{--                    <li class="nav-item">--}}
{{--                        <a href="{{ route('badge-settings.index') }}" class="nav-link">--}}
{{--                            <i class="nav-icon fa-solid fa-gears"></i>--}}
{{--                            <p>Настройки бэйджа</p>--}}

{{--                        </a>--}}
{{--                    </li>--}}
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col-12">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul class="list-unstyled">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    @if (session()->has('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif

                    @if (session()->has('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                </div>
            </div>
        </div>

        @yield('content')
    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer">
        <div class="float-right d-none d-sm-block">
            {{--<b>Version</b> 3.0.5--}}
        </div>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<script src="{{ asset('assets/front/js/jquery-3.2.1.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="{{ asset('assets/admin/js/chart.js') }}"></script>
{{--<script src="https://www.amcharts.com/lib/4/core.js"></script>--}}
{{--<script src="https://www.amcharts.com/lib/4/geodata/worldLow.js"></script>--}}
{{--<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>--}}
{{--<script src="{{ asset('assets/admin/js/table2excel.js') }}"></script>--}}
<script src="{{ asset('assets/admin/js/tableToExcel.js') }}"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>

<script src="{{ asset('assets/admin/js/admin.js') }}"></script>
<script>

    // Для открытия активного меню в админке при переходе
    $('.nav-sidebar a').each(function () {
        let location = window.location.protocol + '//' + window.location.host + window.location.pathname;
        let link = this.href;
        if (link == location) {
            $(this).addClass('active');
            $(this).closest('.has-treeview').addClass('menu-open');
        }
    });

    $(document).ready(function () {
        bsCustomFileInput.init();
    });

    $(document).ready(function() {
        $('.js-example-basic-single').select2();
    });
</script>

<script>
    let button = document.querySelector("#downloadexcel");

    button.addEventListener("click", e => {
        let table = document.querySelector("#data-table");
        TableToExcel.convert(table);
    });
</script>

{{--<script type="text/javascript">--}}
{{--    var block = document.getElementById("progress-week");--}}
{{--    block.scrollLeft += 20;--}}
{{--</script>--}}




</body>
</html>
