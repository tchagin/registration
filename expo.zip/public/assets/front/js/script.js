$(function(){

	$('.header__burger').click(function(event){
		$('.header__burger,.header__menu').toggleClass('active');
		$('body').toggleClass('lock');
	});


	// $('.exhibitions .step-1 .next-step').click(function(){
	// 	if ($('input[name=radio]:checked').length > 0) {
	// 		$('.exhibitions .step-1').css('display', 'none');
	// 		$('.exhibitions .step-2').css('display', 'block');
	// 	}else{
	// 		alert('Выберите выставку');
	// 	}
	// })
	// $('.exhibitions .step-2 .prew-step').click(function(){
	// 	$('.exhibitions .step-2').css('display', 'none');
	// 	$('.exhibitions .step-1').css('display', 'block');
	// })

	$('.current-lang').click(function(){
		$('.other-lang').slideToggle();
	})

    // $('#country').click(function(){
    //     $('ul.ms-options').slideToggle();
    // })

    $("#select").select2({
        tags: true,
// dropdownParent: $('#modal), // if select in modal
//         theme: "bootstrap",
        theme: "classic"
    });


});
