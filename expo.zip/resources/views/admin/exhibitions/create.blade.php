@extends('admin.layouts.layout')

@section('content')

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            @include('admin.exhibitions.form')
        </div>
    </section>
    <!-- /.content -->
@endsection
