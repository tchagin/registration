<?php

namespace App\Http\Controllers\Admin\QrPanel;

use App\Http\Controllers\Controller;
use App\Models\Exhibition;
use Illuminate\Http\Request;

class QrPanelController extends Controller
{
    public function index(){
        $exhibitions = Exhibition::orderBy('id', 'desc')->get();
        return view('admin.panel.index', compact('exhibitions'));
    }
}
