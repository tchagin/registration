<?php

namespace App\Providers;

use App\Models\BadgeSettings;
use App\Models\Country;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
//        $settings = BadgeSettings::latest()->first();
//        if (isset($settings)){
//            view()->share([
//                'settings' => $settings,
//            ]);
//        }else{
//            $settings = BadgeSettings::create([
//                'id' => 1,
//                'height' => 80,
//                'width' => 60,
//                'orientation' => 'vertically',
//                'status' => 'on',
//            ]);
////            view()->share('settings', $settings);
//            view()->share([
//                'settings' => $settings,
//            ]);
//        }
    }
}
