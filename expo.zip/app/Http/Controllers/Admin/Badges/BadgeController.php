<?php

namespace App\Http\Controllers\Admin\Badges;

use App\Http\Controllers\Controller;
use App\Models\BadgeSettings;
use Illuminate\Http\Request;

class BadgeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
//        $settings = BadgeSettings::get();
        return view('admin.badges.index');
//        return view('admin.badges.index', compact('settings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.badges.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
           'width' => 'required',
           'height' => 'required',
           'status' => 'nullable'
        ]);

        $data = $request->all();
        BadgeSettings::create($data);
        return redirect()->route('badge-settings.index')->with('success', 'Настройки созданы');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $setting = BadgeSettings::find($id);
        return view('admin.badges.edit', compact('setting'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
//        dd($request->all());
        $request->validate([
            'width' => 'required',
            'height' => 'required',
            'status' => 'nullable',
            'orientation' => 'required',
        ]);

        $data = $request->all();
        $setting = BadgeSettings::find($id);
        $setting->update($data);
        return redirect()->route('badge-settings.index')->with('success', 'Настройки изменены');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
